Kratos TrueType - God of War font
=================================
    ---Made by AngelorD---

The new and improved version of my God of War font replica is here!

---------------------
This version includes:
---------------------
*ALL punctuation marks are included, and some existing ones were improved!
*New highly detailed brackets from all 3 kinds!
*$ sign was improved to have an "of" inside to write GOD of WAR like in the logos!
*Some letters were improved to look smoother and nicer!
*Regular numbers were replaced by Roman numbers, which matches perfectly with the theme of the game!
*To use regular numbers, press Alt+(Chosen Number on the right portion of the keyboard).
*To use 0 press Alt+0147(Again,on the right portion of the keyboard).�
*More various punctuation marks were added.



~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
Enjoy and Rate at DaFont.com!!!
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
Released Friday March 28th 2008

